
import './App.css';
import ColorSchemesExample from './navbar';
import DarkVariantExample from './slider';
import HeaderAndFooterExample from './card';
import BasicExample from './card1';
import BasicExample2 from './card2';
import BasicExample3 from './card3';


function App() {
  return (
    <div className="App">
      <ColorSchemesExample/>
      <DarkVariantExample/>
      <HeaderAndFooterExample/>
      <BasicExample/>
      <BasicExample2/>
      <BasicExample3/>
      
   
    </div>
  );
}

export default App;
