import Carousel from 'react-bootstrap/Carousel';

function DarkVariantExample() {
  return (
    <Carousel variant="dark" className='slides'>
      <Carousel.Item>
        <img
          className="d-block w-100 abc"
          src="https://cdn.pixabay.com/photo/2018/07/05/16/59/students-3518726_960_720.jpg"
          alt="First slide"
        />
        <Carousel.Caption>
          <h5 className='heading'>Welcome to ARC School</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100 abc"
          src="https://media.istockphoto.com/id/819615274/vector/group-of-pupils-walking-in-school-corridor-to-class-room-mix-race-schoolchildren.jpg?s=1024x1024&w=is&k=20&c=0giqDmx7pLSxhHOQ59Bu4exvULEcFFaO3fcmXFvJtms="
          alt="Second slide"
        />
        <Carousel.Caption>
          <h5 className='heading'>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100 abc"
          src="https://media.istockphoto.com/id/1059510610/vector/it-communication-e-learning-internet-network-as-knowledge-base.jpg?s=1024x1024&w=is&k=20&c=kmwjqSyGp0deNokYdBz6avSvWv6aRujZ8LDuIxul4cc="
          alt="Third slide"
        />
        <Carousel.Caption>
          <h5 className='heading'>Third slide label</h5>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default DarkVariantExample;